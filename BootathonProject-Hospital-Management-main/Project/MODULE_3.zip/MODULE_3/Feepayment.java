package MODULE_3;
import javax.swing.*;

import MODULE_2.Login;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Feepayment {
    String id;int paid;
    private Feepayment(){
        JFrame f=new JFrame();

       
        JButton Back_Button=new JButton("BACK");Back_Button.setBounds(20,120,100,30);
        Back_Button.setFont(new Font("Verdana", Font.PLAIN,11));Back_Button.setBackground(new Color(171,222,158));
        JButton Search_Button=new JButton("SEARCH");Search_Button.setBounds(1150,220,150,40);
        Search_Button.setFont(new Font("Verdana", Font.PLAIN,11));Search_Button.setBackground(new Color(171,222,158));
        JButton Pay_Button=new JButton("PAY");Pay_Button.setBounds(900,620,150,40);
        Pay_Button.setFont(new Font("Verdana", Font.PLAIN,15));Pay_Button.setBackground(new Color(171,222,158));
        JButton Check_Balance_Button=new JButton("CHECK BALANCE");Check_Balance_Button.setBounds(1500,520,150,40);
        Check_Balance_Button.setFont(new Font("Verdana", Font.PLAIN,11));Check_Balance_Button.setBackground(new Color(171,222,158));

        JLabel l= new JLabel("Hospital Management System",JLabel.CENTER);
        l.setOpaque(true);
        l.setForeground(Color.BLACK);
        l.setBackground(new Color(171,222,158));
        l.setFont(new Font("Verdana",Font.PLAIN,30));
        l.setBounds(0,20,1920,90);


        JLabel Footer_Label=new JLabel("FEE PAYMENT",JLabel.CENTER);
        Footer_Label.setOpaque(true);
        Footer_Label.setForeground(Color.BLACK);
        Footer_Label.setFont(new Font("Verdana",Font.PLAIN,20));
        Footer_Label.setBounds(800,120,300,30);
        Footer_Label.setBackground(new Color(215, 247, 224));

        JLabel Enter_ID_Label=new JLabel("ENTER THE ID",JLabel.CENTER);
        Enter_ID_Label.setOpaque(true);
        Enter_ID_Label.setForeground(Color.BLACK);
        Enter_ID_Label.setFont(new Font("Verdana",Font.PLAIN,20));
        Enter_ID_Label.setBounds(600,226,300,30);
        Enter_ID_Label.setBackground(new Color(215, 247, 224));

        JLabel Name_Label=new JLabel("NAME",JLabel.CENTER);
        Name_Label.setOpaque(true);
        Name_Label.setForeground(Color.BLACK);
        Name_Label.setFont(new Font("Verdana",Font.PLAIN,20));
        Name_Label.setBounds(560,326,300,30);
        Name_Label.setBackground(new Color(215, 247, 224));

        JLabel Fees_Label=new JLabel("FEES",JLabel.CENTER);
        Fees_Label.setOpaque(true);
        Fees_Label.setForeground(Color.BLACK);
        Fees_Label.setFont(new Font("Verdana",Font.PLAIN,20));
        Fees_Label.setBounds(560,426,300,30);
        Fees_Label.setBackground(new Color(215, 247, 224));

        JLabel Amount_Paid_Label=new JLabel("AMOUNT PAID",JLabel.CENTER);
        Amount_Paid_Label.setOpaque(true);
        Amount_Paid_Label.setForeground(Color.BLACK);
        Amount_Paid_Label.setFont(new Font("Verdana",Font.PLAIN,20));
        Amount_Paid_Label.setBounds(400,526,300,30);
        Amount_Paid_Label.setBackground(new Color(215, 247, 224));

        JLabel Change_Label=new JLabel("CHANGE",JLabel.CENTER);
        Change_Label.setOpaque(true);
        Change_Label.setForeground(Color.BLACK);
        Change_Label.setFont(new Font("Verdana",Font.PLAIN,20));
        Change_Label.setBounds(930,526,200,30);
        Change_Label.setBackground(new Color(215, 247, 224));



        JTextField t1=new JTextField();t1.setBounds(900,220,200,40);
        t1.setFont(new Font("Verdana", Font.PLAIN,20));

        JTextField t2=new JTextField();t2.setBounds(900,320,300,40);
        t2.setFont(new Font("Verdana", Font.PLAIN,20));

        JTextField t3=new JTextField();t3.setBounds(900,420,200,40);
        t3.setFont(new Font("Verdana", Font.PLAIN,20));
        t3.setEditable(false);

        JTextField t4=new JTextField();t4.setBounds(730,520,200,40);
        t4.setFont(new Font("Verdana", Font.PLAIN,20));


        JTextField t5=new JTextField();t5.setBounds(1200,520,200,40);
        t5.setFont(new Font("Verdana", Font.PLAIN,20));
        t5.setEditable(false);

        Back_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String s[]={};
                Receptionist.getInstance();
                f.setVisible(false);
            }
        });

        Search_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                id=t1.getText();
                try{
                    t2.setText("");
                    t3.setText("");
                    t4.setText("");
                    t5.setText("");
                    
                    PreparedStatement ps=Login.getConnection().prepareStatement("SELECT * from patient WHERE ID=(?) AND Doctor=?");
                    ps.setString(1,t1.getText());
                    ps.setString(2, Receptionist.Doc_Recp_ID);
                    ResultSet rs = ps.executeQuery();
                    while(rs.next()){
                        t2.setText(rs.getString(1));
                        t3.setText(String.valueOf(rs.getInt(14)));
                    }
                }
                catch (Exception ex){
                    System.out.println(ex);
                }
            }
        });
        Pay_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int change=Integer.parseInt(t5.getText());
                if(change>=0){
                    try{
                        PreparedStatement ps=Login.getConnection().prepareStatement("UPDATE patient SET FEES=(?) WHERE ID=(?) AND Doctor=?");
                        ps.setInt(1,0);
                        ps.setString(2,id);
                        ps.setString(3, Receptionist.Doc_Recp_ID);
                        int a=ps.executeUpdate();
                         
                        JOptionPane.showMessageDialog(f, "PAYMENT SUCCESSFULL", "Success", JOptionPane.WARNING_MESSAGE);
                        t1.setText("");
                        t2.setText("");
                        t3.setText("");
                        t4.setText("");
                        t5.setText("");

                    }
                    catch (Exception ex){
                        System.out.println(ex);
                    }
                }
                else{
                    JOptionPane.showMessageDialog(f, "PAYMENT NOT SUCCESSFULL", "Alert", JOptionPane.WARNING_MESSAGE);
                }
            }
        });

        Check_Balance_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if((t4.getText().isEmpty())||(t1.getText().isEmpty())){
                    JOptionPane.showMessageDialog(f, "ENTER AMOUNT PAID and ID", "Alert", JOptionPane.WARNING_MESSAGE);
                }
                else{
                     paid=Integer.parseInt(t4.getText());
                    try{
                        PreparedStatement ps=Login.getConnection().prepareStatement("SELECT * from patient WHERE ID=(?) AND Doctor=?");
                        ps.setString(1,t1.getText());
                        ps.setString(2, Receptionist.Doc_Recp_ID);
                        ResultSet rs = ps.executeQuery();
                        while(rs.next()){
                            t5.setText(String.valueOf(paid-(rs.getInt(14))));
                        }
                         
                    }
                    catch (Exception ex){
                        System.out.println(ex);
                    }
                }
            }
        });

        f.setSize(1920, 1080);
        f.getContentPane().setBackground(new Color(215, 247, 224));
        f.setLayout(null);
        f.setResizable(true); f.setDefaultCloseOperation(3);
        f.add(l);f.add(Back_Button);f.add(Footer_Label);f.add(Search_Button);f.add(Enter_ID_Label);f.add(Name_Label);f.add(t1);f.add(t2);f.add(Fees_Label);f.add(t3);f.add(Amount_Paid_Label);f.add(t4);f.add(Change_Label);
        f.add(t5);f.add(Pay_Button);f.add(Check_Balance_Button);
        f.setVisible(true);

    }
    public static Feepayment getInstance(){
        return new Feepayment();
    }
}
